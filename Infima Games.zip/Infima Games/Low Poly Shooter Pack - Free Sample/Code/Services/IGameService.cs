﻿// Copyright 2021, Infima Games. All Rights Reserved.

namespace InfimaGames.LowPolyShooterPack
{
    public interface IGameService
    {
        
    }
}